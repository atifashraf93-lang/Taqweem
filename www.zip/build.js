window.SMAA_BUILD = 42;
