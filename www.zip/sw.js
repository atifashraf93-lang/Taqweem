/* Taqweem service worker: caches the app shell and fonts so it opens offline.
   Audio is streamed and never cached. */
var VERSION = 'taqweem-v26';
var SHELL = ['./', 'index.html', 'core.js', 'data.js', 'hadith.js', 'naat.js', 'duas.js', 'books.js', 'remote.js', 'qdata.js', 'app.js', 'seerat-data.js', 'seerat-detail.js', 'seerat-detail-a1.js', 'seerat-detail-a2.js', 'seerat-detail-s1.js', 'seerat-detail-s2.js', 'seerat-detail-h1.js', 'umrah-data.js', 'umrah.js', 'banners.js', 'daily.js', 'extras.js', 'seerat.js', 'extras.css', 'manifest.webmanifest', 'icon.svg', 'img/quran.jpg', 'img/madina.jpg'];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(VERSION).then(function (c) { return c.addAll(SHELL); }).then(function () { return self.skipWaiting(); }));
});

self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (keys) {
    return Promise.all(keys.filter(function (k) { return k !== VERSION; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});

self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET') return;
  var url = new URL(req.url);
  var isFont = url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com';
  if (url.origin !== location.origin && !isFont) return;
  e.respondWith(
    caches.match(req).then(function (hit) {
      var net = fetch(req).then(function (res) {
        if (res && (res.ok || res.type === 'opaque')) {
          var copy = res.clone();
          caches.open(VERSION).then(function (c) { c.put(req, copy); });
        }
        return res;
      }).catch(function () { return hit; });
      return hit || net;
    })
  );
});
